-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2021 at 09:19 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `signup`
--

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `track_num` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` decimal(10,0) NOT NULL,
  `shipping_add` varchar(255) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_details_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_qty` int(11) NOT NULL,
  `total` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_details_id`, `prod_id`, `prod_qty`, `total`, `user_id`, `order_id`) VALUES
(1, 1, 8, 600, 10, '1'),
(2, 2, 4, 200, 8, '1'),
(5, 3, 1, 80, 10, '1'),
(6, 1, 1, 0, 0, ''),
(7, 2, 1, 0, 0, ''),
(8, 3, 1, 0, 0, ''),
(9, 4, 1, 0, 0, ''),
(10, 5, 1, 0, 0, ''),
(11, 6, 1, 0, 0, ''),
(12, 7, 1, 0, 0, ''),
(13, 8, 1, 0, 0, ''),
(14, 9, 1, 0, 0, ''),
(15, 10, 1, 0, 0, ''),
(16, 11, 1, 0, 0, ''),
(17, 12, 1, 0, 0, ''),
(18, 13, 1, 0, 0, ''),
(19, 14, 1, 0, 0, ''),
(20, 15, 1, 0, 0, ''),
(21, 1, 1, 0, 0, ''),
(22, 2, 1, 0, 0, ''),
(23, 3, 1, 0, 0, ''),
(24, 4, 1, 0, 0, ''),
(25, 5, 1, 0, 0, ''),
(26, 6, 1, 0, 0, ''),
(27, 7, 1, 0, 0, ''),
(28, 8, 1, 0, 0, ''),
(29, 9, 1, 0, 0, ''),
(30, 10, 1, 0, 0, ''),
(31, 11, 1, 0, 0, ''),
(32, 12, 1, 0, 0, ''),
(33, 13, 1, 0, 0, ''),
(34, 14, 1, 0, 0, ''),
(35, 15, 1, 0, 0, ''),
(59, 3, 1, 80, 8, '1'),
(60, 1, 1, 75, 8, '1'),
(61, 13, 1, 45, 8, '1'),
(62, 13, 1, 45, 8, '1'),
(63, 6, 1, 40, 8, '1'),
(64, 3, 1, 80, 8, '1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(5) NOT NULL,
  `prod_desc` varchar(255) NOT NULL,
  `prod_name` varchar(255) NOT NULL,
  `prod_price` int(10) NOT NULL,
  `prod_p1` varchar(255) NOT NULL,
  `prod_p2` varchar(255) NOT NULL,
  `prod_p3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `prod_desc`, `prod_name`, `prod_price`, `prod_p1`, `prod_p2`, `prod_p3`) VALUES
(1, 'These Apple Pie Cupcakes feature a decadent vanilla cinnamon cupcake with apple pie filling & topped with vanilla cinnamon buttercream.', 'Apple Pie ', 75, 'product 1_1.jpg', 'product 1_2.jpg', 'product 1_3.jpg'),
(2, 'These banoffee pie cupcakes have it all – the soft and moist banana cupcakes, the luscious caramel centre and the fluffiest of whipped cream frostings. Complete with a generous sprinkle of chocolate shavings, they are delicious to eat', 'Banoffee', 50, 'product 2_1.jpg', 'product 2_2.jpg', 'product 2_3.jpg'),
(3, 'These black forest cupcakes have a moist chocolate base, homemade cherry filling, and a light whipped cream topping.', 'Black Forest', 80, 'product 3_1.jpg', 'product 3_2.jpg', 'product 3_3.jpg'),
(4, 'Carrot Cupcakes are moist and flavorful with grated carrots and nuts and are frosted with a delicious cream cheese frosting', 'Carrot Cupcakes', 30, 'product 4_1.jpg', 'product 4_2.jpg', 'product 4_3.jpg'),
(5, 'Chocolate-chocolate cupcake with double the flavor with a moist chocolate and a rich chocolate buttercream frosting', 'Chocolate', 50, 'product 5_1.jpg', 'product 5_2.jpg', 'product 5_3.jpg'),
(6, 'One of the best cupcakes we make! Rich and light coconut cupcakes with a creamy coconut frosting.', 'Coconut', 40, 'product 6_1.jpg', 'product 6_2.jpg', 'product 6_3.jpg'),
(7, 'Super soft and moist Coffee Cupcakes topped with ultra creamy Coffee Mascarpone Frosting.', 'Coffee', 55, 'product 7_1.jpg', 'product 7_2.jpg', 'product 7_3.jpg'),
(8, 'These delicious Oreo cupcakes will melt in your mouth and that cookies and cream frosting on top is nearly too good too be true.', 'Cookies and Cream', 80, 'product 8_1.jpg', 'product 8_2.jpg', 'product 8_3.jpg'),
(9, 'Blueberry Lemonade Cupcakes that will add a hint of refreshing to any summer gathering or party.', 'Lemonade and Blueberry', 60, 'product 9_1.jpg', 'product 9_2.jpg', 'product 9_3.jpg'),
(10, 'If you\'re a peanut butter lover, these cupcakes are for you! They are full of peanut flavor, light, fluffy, and moist.', 'Peanut Butter', 45, 'product 10_1.jpg', 'product 10_2.jpg', 'product 10_3.jpg'),
(11, 'These soft buttery raspberry cupcakes are topped with sweet raspberry buttercream and packed with fresh raspberries.', 'Raspberry', 45, 'product 11_1.jpg', 'product 11_2.jpg', 'product 11_3.jpg'),
(12, 'Red Velvet Cupcakes ... These Red Velvet Cupcakes are soft, light, moist, and topped with an easy cream cheese frosting. Perfect for any occasion!', 'Red Velvet', 90, 'product 12_1.jpg', 'product 12_2.jpg', 'product 12_3.jpg'),
(13, 'Supremely moist brown sugar cupcakes are stuffed with caramel cream and topped with salted caramel frosting. ', 'Salted Caramel', 45, 'product 13_1.jpg', 'product 13_2.jpg', 'product 13_3.jpg'),
(14, 'These Fresh Strawberry Cupcakes are moist, tender and delicious! There are chopped strawberries in the cupcake and strawberry buttercream!', 'Strawberry', 35, 'product 14_1.jpg', 'product 14_2.jpg', 'product 14_3.jpg'),
(15, 'Vanilla Cupcakes are so lovely with their swirls of Buttercream Frosting and Vanilla Flower Cupcakes and Vanilla Bean Cupcakes.', 'Vanilla', 35, 'product 15_1.jpg', 'product 15_2.jpg', 'product 15_3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` decimal(10,0) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `email`, `contact`, `password`) VALUES
(7, 'xyz', 'xyz@bush.com', '0', '$2y$10$O5BoiYOdlBaH.t9MoNWUtubEaoc9lHsr91bMGqO4.Xw'),
(8, 'abc', 'abc@x.com', '0', '$2y$10$yOcckLElw9fxsgiw3Wq3XuO7J2v77SI20MbNWL9umKE4INaL2Ra1W'),
(9, 'aka', 'ak@gmail.com', '0', '$2y$10$/b1lgQ/rNY/PVao03ZsG0Ob5wXjqgHBUjeNmogwRL8vSQVi8OVA36'),
(10, 'abc', 'x@gmail.com', '0', '$2y$10$nb8CpH4kkpsAeX/p368vV.lREySIr9xl7oIFE4m86TJK72cAkvtje'),
(11, 'abc', 'abc@gmail.com', '0', '$2y$10$pcWpQZMWhzPwCDYqX0TlWOc9oPNpjb7F0Mr/RtxGrXpsjkCASq7kG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
